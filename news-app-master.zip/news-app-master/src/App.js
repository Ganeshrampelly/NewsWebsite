import './App.css';
import { NewsList } from './components'

function App() {
  return (
    <div className="App">
      <NewsList />
    </div>
  );
}

export default App;
